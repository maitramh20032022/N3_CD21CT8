package test;

import driver.driverFactory;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.List;

@Test
public class TestCase5 {
    public static void TestCase5(){
        WebDriver driver = new EdgeDriver();
        try{
                //Step 1:
                driver.get("http://live.techpanda.org/");
                // Step 2:
                By leftClickPlace = By.xpath("//span[@class='label'][normalize-space()='Account']");
                WebElement leftClickPlaceElem = driver.findElement(leftClickPlace);
                leftClickPlaceElem.click();
                    By leftClickPlace1 = By.cssSelector("div[id='header-account'] a[title='My Account']");
                WebElement leftClickPlaceElem1 = driver.findElement(leftClickPlace1);
                leftClickPlaceElem1.click();
                //Step 3:
                By leftClickPlace2 = By.cssSelector("a[title='Create an Account'] span span");
                WebElement leftClickPlaceElem2 = driver.findElement(leftClickPlace2);
                leftClickPlaceElem2.click();


                WebElement usernameElem = driver.findElement(By.cssSelector("#firstname"));
                WebElement middleElem = driver.findElement(By.cssSelector("#middlename"));
                WebElement lastnameElem = driver.findElement(By.cssSelector("#lastname"));
                WebElement emailElem = driver.findElement(By.cssSelector("#email_address"));
                WebElement passElem = driver.findElement(By.cssSelector("#password"));
                WebElement compassElem = driver.findElement(By.cssSelector("#confirmation"));

                //
                usernameElem.sendKeys("Tran");
                middleElem.sendKeys("Thai");
                lastnameElem.sendKeys("Tong");
                emailElem.sendKeys("tranthaitong6@gmail.com");
                passElem.sendKeys("1234567890");
                compassElem.sendKeys("1234567890");


                // Step 4:
                By leftClickPlace3 = By.xpath("//span[contains(text(),'Register')]");
                WebElement leftClickPlaceElem3 = driver.findElement(leftClickPlace3);
                leftClickPlaceElem3.click();

//              By welcom =  (("WELCOM " + usernameElem + middleElem + lastnameElem ));

                // Step 6:
            By leftClickPlace4 = By.xpath("//a[normalize-space()='TV']");
            WebElement leftClickPlaceElem4 = driver.findElement(leftClickPlace4);
            leftClickPlaceElem4.click();
                // Step 7:

            By leftClickPlace5 = By.xpath("/html[1]/body[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[2]/ul[1]/li[1]/div[1]/div[3]/ul[1]/li[1]/a[1]");
            WebElement leftClickPlaceElem5 = driver.findElement(leftClickPlace5);
            leftClickPlaceElem5.click();

            // Step 8:
            By leftClickPlace6 = By.cssSelector("button[title='Share Wishlist']");
            WebElement leftClickPlaceElem6 = driver.findElement(leftClickPlace6);
            leftClickPlaceElem6.click();

            // Step 9
            WebElement emailElem1 = driver.findElement(By.cssSelector("#email_address"));
            emailElem1.sendKeys("tranthaitong5@gmail.com");
            WebElement msgElem = driver.findElement(By.cssSelector("#message"));
            msgElem.sendKeys("Ti Vy đen thui ");

            By leftClickPlace7 = By.cssSelector("button[title='Share Wishlist'] span span");
            WebElement leftClickPlaceElem7 = driver.findElement(leftClickPlace7);
            leftClickPlaceElem7.click();

            // Step 10:


        }catch (Exception e) {
            e.printStackTrace();
        }

        //7. Quit browser session
//        driver.quit();
    }
}
