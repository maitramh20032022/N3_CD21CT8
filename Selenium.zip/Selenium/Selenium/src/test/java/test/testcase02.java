package test;

import driver.driverFactory;
import org.openqa.selenium.*;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;
import java.time.Duration;

@Test
public class testcase02 {
    public static void testcase02() {
//Init web-driver session
        WebDriver driver = new EdgeDriver();
        try {
//Step 1. Go to https://cachep.vn/
            driver.get("https://cachep.vn/");
//Step 2. Click on -> Sách Thiếu Nhi
            WebElement leftClickPlaceElem = driver.findElement(By.cssSelector("div[class='grid__item pd-left0 large--eight-twelfths'] li:nth-child(1) a:nth-child(1)"));
            leftClickPlaceElem.click();
            Thread.sleep(2000);
//Step 3. In the list of all mobile , read the cost of Sony Xperia mobile (which is $100)
            WebElement leftClickPlaceElem1 = driver.findElement(By.xpath("//label[contains(text(),'Từ 100,000₫ - 200,000₫')]//span[@class='checkmark']"));
            leftClickPlaceElem1.click();
            Thread.sleep(2000);
//Step 4. Click
            WebElement leftClickPlaceElem2 = driver.findElement(By.xpath("//a[contains(text(),'Khám phá thế giới (Cuốn lẻ)')]"));
            leftClickPlaceElem2.click();
            Thread.sleep(2000);
//Step 5. Read the Sony Xperia mobile from detail page.
 //           WebElement detailPrice = driver.findElement(By.xpath("//span[@id='product-price-1']/span"));
   //         String actualPrice = detailPrice.getText();
     //       System.out.println("Price of Sony Xperia on Detail page: " + actualPrice);
       //     Thread.sleep(2000);
//Step 6. Compare Product value in list and details page should be equal ($100).
//            Assert.assertEquals(actualPrice, expectedPrice);
//Take screenshot
            TakesScreenshot screenshot = ((TakesScreenshot) driver);
            File srcFile = screenshot.getScreenshotAs(OutputType.FILE);
            File destFile = new File(".\\src\\test\\java\\test\\testcase02.png");
            FileHandler.copy(srcFile, destFile);
            Thread.sleep(2000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        //7. Quit browser session
        driver.quit();
    }
}