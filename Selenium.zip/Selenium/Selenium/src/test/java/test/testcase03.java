package test;

import driver.driverFactory;
import org.openqa.selenium.*;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;
import java.time.Duration;

@Test
public class testcase03 {
    public static void testcase03() {
        //Init web-driver session
        WebDriver driver = new EdgeDriver();
        try {
            //Step 1. Go to https://cachep.vn/
            driver.get("https://cachep.vn/");

            //Step 2. Click on -> Sách Thiếu Nhi
            WebElement sachthieunhiMenu = driver.findElement(By.cssSelector("div[class='grid__item pd-left0 large--eight-twelfths'] li:nth-child(1) a:nth-child(1)"));
            sachthieunhiMenu.click();
            Thread.sleep(2000);
            //Step 3. In the list of all mobile , click on “ADD TO CART” for Sony Xperia mobile
            WebElement sonyXperiaAddToCartButton = driver.findElement(By.xpath("//div[@class='grid-uniform product-list mg-left-0']//div[1]//div[1]//div[5]//button[3]"));
            sonyXperiaAddToCartButton.click();
            Thread.sleep(2000);
            //Step 4. Change “QTY” value to 1000 and click “UPDATE” button. Expected that an error is displayed "The requested quantity for "Sony Xperia" is not available."
            WebElement qtyInputBox = driver.findElement(By.xpath("//input[@id='updates_']"));
            qtyInputBox.clear();
            qtyInputBox.sendKeys("1000");
            WebElement updateButton = driver.findElement(By.xpath("//button[@name='update']"));
            updateButton.click();
            Thread.sleep(2000);

            //Step 5. Verify the error message

            //Step 6. Then click on “EMPTY CART” link in the footer of list of all mobiles. A message "SHOPPING CART IS EMPTY" is shown.
            WebElement emptyCartLink = driver.findElement(By.xpath("//td[@class='product-remove']//a[@class='cart__remove']"));
            emptyCartLink.click();
            Thread.sleep(2000);
            //Step 7. Verify cart is empty
            TakesScreenshot screenshot = ((TakesScreenshot) driver);
            File srcFile = screenshot.getScreenshotAs(OutputType.FILE);
            File destFile = new File(".\\src\\test\\java\\test\\testcase03.png");
            FileHandler.copy(srcFile, destFile);
            Thread.sleep(2000);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //Close web-driver
            driver.quit();
        }
    }
}
