/* Verify user is able to purchase product using registered email id(USE CHROME BROWSER)
Test Steps:
1. Go to http://live.techpanda.org/
2. Click on my account link
3. Login in application using previously created credential
4. Click on MY WISHLIST link
5. In next page, Click ADD TO CART link
6. Enter general shipping country, state/province and zip for the shipping cost estimate
7. Click Estimate
8. Verify Shipping cost generated
9. Select Shipping Cost, Update Total
10. Verify shipping cost is added to total
11. Click "Proceed to Checkout"
12a. Enter Billing Information, and click Continue
12b. Enter Shipping Information, and click Continue
13. In Shipping Method, Click Continue
14. In Payment Information select 'Check/Money Order' radio button. Click Continue
15. Click 'PLACE ORDER' button
16. Verify Oder is generated. Note the order number

NOTE: PROCEED TO CHECKOUT (step 6 ) was taken out, so as to allow the Estimate button step to get processed.
Rest of the steps renumbered accordingly.
 */
package test;

import driver.driverFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

@Test
public class TestCase6 {
    public static void testCase06() {
        WebDriver driver = new EdgeDriver();
        try {
            // Step 1: Go to https://cachep.vn/
            driver.get("https://cachep.vn/");
            // Step 2. Login in application using previously created credential
            WebElement logBtn = driver.findElement(By.cssSelector("div[class='grid__item large--two-thirds'] li:nth-child(1) a:nth-child(1)"));
            logBtn.click();
            WebElement emailLog = driver.findElement(By.cssSelector("#CustomerEmail"));
            emailLog.clear();
            emailLog.sendKeys("trantongkudo2003@gmail.com");
            WebElement passLog = driver.findElement(By.cssSelector("#CustomerPassword"));
            passLog.clear();
            passLog.sendKeys("1234567890");
            WebElement logLog = driver.findElement(By.cssSelector("input[value='Đăng nhập']"));
            logLog.click();
            // Step 3. Click Home
            WebElement logLog1 = driver.findElement(By.cssSelector("a[title='Quay trở về trang chủ']"));
            logLog1.click();
            // Step 4. In next page, Click ADD TO CART link
            WebElement atcBtn = driver.findElement(By.xpath("//section[@id='home-module-products1']//div[@class='grid-uniform mg-left-10']//div[1]//a[1]//div[2]"));
            atcBtn.click();
            WebElement atcBtn1 = driver.findElement(By.xpath("//button[@id='AddToCart']"));
            atcBtn1.click();

            WebElement atcBtn2 = driver.findElement(By.xpath("//form[@class='cart table-wrap medium--hide small--hide']//button[@name='checkout'][normalize-space()='Thanh toán']"));
            atcBtn2.click();
            //Step 5. Enter general shipping country, state/province and zip for the shipping cost estimate

            WebElement regionInput= driver.findElement(By.cssSelector("#billing_address_full_name"));
            regionInput.clear();
            regionInput.sendKeys("Trkn fdfgf");

            WebElement phone= driver.findElement(By.cssSelector("#billing_address_phone"));
            phone.clear();
            phone.sendKeys("0125412356");

            WebElement add = driver.findElement(By.xpath("//input[@id='billing_address_address1']"));
            add.clear();
            add.sendKeys("Bắc Kạn");

            WebElement countrySelect= driver.findElement(By.xpath("//select[@id='customer_shipping_province']"));
            Select select = new Select(countrySelect);
            select.selectByVisibleText("Bắc Kạn");

            WebElement countrySelect1= driver.findElement(By.xpath("//select[@id='customer_shipping_district']"));
            Select select1 = new Select(countrySelect1);
            select1.selectByVisibleText("Huyện Na Rì");

            WebElement countrySelect2= driver.findElement(By.xpath("//select[@id='customer_shipping_ward']"));
            Select select2 = new Select(countrySelect2);
            select2.selectByVisibleText("Xã Kim Hỷ");

//            // Step 7. Click Estimate
            WebElement estimateBtn= driver.findElement(By.cssSelector("//button[@class='step-footer-continue-btn btn']"));
            estimateBtn.click();
//            // Step 8. Verify Shipping cost generated
            WebElement labelShip = driver.findElement(By.cssSelector(".radio-accessory.content-box-emphasis"));
            if (labelShip.isDisplayed()){
                System.out.println("Đã tạo phí vận chuyển");
            }else{
                System.out.println("Chưa tạo phí vận chuyển");
            }
//            // step 9. Select Shipping Cost, Update Total
//            // Step 10. Verify shipping cost is added to total

            WebElement labelShip1 = driver.findElement(By.cssSelector(".payment-due-price"));
            if (labelShip1.isDisplayed()){
                System.out.println("Đã update cost");
            }else{
                System.out.println("Chưa update cost");
            }

//            // Step 11. Click "Proceed to Checkout"
//
//            // Step 12. Enter Billing Information, and click Continue
//
//            // Step 13. In Shipping Method, Click Continue
//
//            // Step 14. In Payment Information select 'Check/Money Order' radio button. Click Continue
//
//            // Step 15. Click 'PLACE ORDER' button
//            // Step 16. Verify Oder is generated. Note the order number
        } catch (Exception e) {
            e.printStackTrace();
        }
//        driver.quit();
    }
}