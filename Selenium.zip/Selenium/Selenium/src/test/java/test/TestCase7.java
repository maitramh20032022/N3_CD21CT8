/*Verify that you will be able to save previously placed order as a pdf file
        *
        *   Note: This TestCase7a version is due to the below amended steps.
        *
        Test Steps:
        1. Go to http://live.techpanda.org/
        2. Click on My Account link
        3. Login in application using previously created credential
        4. Click on 'My Orders'
        5. Click on 'View Order'
        6. *** note: After steps 4 and 5, step 6 "RECENT ORDERS" was not displayed
        Verify the previously created order is displayed in 'RECENT ORDERS' table and status is Pending
        7. Click on 'Print Order' link
        8. *** note: the link was not found.
        Click 'Change...' link and a popup will be opened as 'Select a destination' , select 'Save as PDF' link.
 */
package test;
import driver.driverFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;
@Test
public class TestCase7 {
    public static void testCase07() {
        WebDriver driver = new EdgeDriver();
        try {
            // Step 1: Go to https://cachep.vn/
            driver.get("https://cachep.vn/");
            // Step 2. Login in application using previously created credential
            WebElement logBtn = driver.findElement(By.cssSelector("div[class='grid__item large--two-thirds'] li:nth-child(1) a:nth-child(1)"));
            logBtn.click();
            WebElement emailLog = driver.findElement(By.cssSelector("#CustomerEmail"));
            emailLog.clear();
            emailLog.sendKeys("trantongkudo2003@gmail.com");
            WebElement passLog = driver.findElement(By.cssSelector("#CustomerPassword"));
            passLog.clear();
            passLog.sendKeys("1234567890");
            WebElement logLog = driver.findElement(By.cssSelector("input[value='Đăng nhập']"));
            logLog.click();

            //Step 3. Click on 'My Orders'
            //Step 4. Click on 'View Order'
            //Step 5. Click on 'Print Order' link
            //Step 6. *** note: the link was not found.

    } catch (Exception e) {
        e.printStackTrace();
    }
        driver.quit();
    }
}
